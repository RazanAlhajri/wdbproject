from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),
    path('add_book/', views.add_book_view, name='add_book'),
    path('all_books/', views.all_books, name='all_books'),
    path('books/<int:pk>/', views.Display_Specific_Book, name='Display_Specific_Book'),
    path('books/<int:pk>/edit/', views.book_update, name='book_update'),
    path('books/<int:pk>/delete/', views.delete_book, name='book_delete'),
]
