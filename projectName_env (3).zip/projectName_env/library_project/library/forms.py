from django import forms
from .models import customr,Book




class LoginForm(forms.Form):
    username = forms.CharField(max_length=200, label="Username")
    password = forms.CharField(widget=forms.PasswordInput, label="Password")


class RegisterForm(forms.Form):
    username = forms.CharField(max_length=200, label="Username")
    password = forms.CharField(widget=forms.PasswordInput, label="Password")

    def clean_username(self):
        username = self.cleaned_data.get("username")
        # Check if the username already exists
        if customr.objects.filter(username=username).exists():
            raise forms.ValidationError("Username already exists.")
        return username



class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'genre']
        labels = {
            'title': 'Book Title',
            'author': 'Author',
            'genre': 'Genre',
        }

