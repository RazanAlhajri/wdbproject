from django.contrib.auth import authenticate, login
from .forms import LoginForm,RegisterForm,BookForm
from .models import customr,Book
from django.contrib import messages
from django.shortcuts import render, redirect
from django.http import Http404


def login_view(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            
            try:
                user = customr.objects.get(username=username)
                if user.check_password(password):  # Use check_password to validate
                    # Log the user in (use sessions or Django auth if applicable)
                    request.session['user_id'] = user.id  # Example using sessions
                    return redirect('all_books')
                else:
                    form.add_error(None, "Invalid username or password.")
            except customr.DoesNotExist:
                form.add_error(None, "Invalid username or password.")
    else:
        form = LoginForm()

    return render(request, "library/login.html", {"form": form})


def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']

            new_user = customr(username=username)
            new_user.set_password(password)  # Hash the password using set_password
            new_user.save()

            messages.success(request, "Account created successfully. Please log in.")
            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, "library/register.html", {"form": form})

def logout_view(request):
    request.session.flush()  # Clears all session data
    return redirect('login')

def all_books(request):
    books = Book.objects.all()  # Retrieve all books from database
    return render(request, 'library/all_books.html', {'books': books})

def add_book_view(request):
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Book added successfully.")
            return redirect('all_books')  # Redirect after adding the book
    else:
        form = BookForm()

    return render(request, 'library/add_book.html', {'form': form})

def Display_Specific_Book(request, pk):
    try:
        book = Book.objects.get(pk=pk)
    except Book.DoesNotExist:
        raise Http404("Book not found")

    if request.method == 'POST' and 'reserve' in request.POST:
        user = customr.objects.get(id=request.session['user_id'])  
        book.reserved_by.add(user)
        messages.success(request, "Book reserved successfully!")
        return redirect('Display_Specific_Book', pk=book.pk)

    return render(request, 'library/Display_Specific_Book.html', {'book': book})

